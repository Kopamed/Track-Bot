import os
import random
import asyncio
import json
import discord
from discord.ext import commands
from dotenv import load_dotenv
import datetime

load_dotenv()
TOKEN = os.getenv('TOKEN')

bot = commands.Bot(command_prefix='k!', case_insensitive=False)

"""
def create_track(trackerID, trackerU, trackedID, trackedU):
    data = load_json("data.json")
    data
"""



def load_json(file_name):
    with open(file_name, "r") as write_file:
        data = write_file.read()
        data = json.loads(data)
    return data



def dump_json(file_name, data):
    with open(file_name, "w") as write_file:
        json.dump(data, write_file)



@bot.event
async def on_ready():
    print(f'{bot.user.name} has connected to Discord!')
    

    
@bot.event
async def on_member_update(before, after):
    
    data = load_json("data.json")
    print(str(after.id) in data)
    print(f"{after} has gone {after.status}")
    
    if str(after.id) in data and data[str(after.id)]["previous"] != str(after.status[0]):
        
        
        
        print("In data")
        print(data[str(after.id)]["previous"])
        print(data[str(after.id)]["trackedByID"])
        data[str(after.id)]["previous"] = str(after.status[0])
        dump_json("data.json", data)
        
        
        for i in range(len(data[str(after.id)]["trackedByID"])):
            
            member = await bot.fetch_user(int(data[str(after.id)]["trackedByID"][i]))
            await member.create_dm()
            
            embed= discord.Embed(
                title="{} is now".format(after),
                description="`{}`".format(str(after.status[0]).upper()),
                colour=discord.Colour(0x187bcd))
                
            embed.set_footer(
                text="https://discord.com/oauth2/authorize?client_id=749989132763136021&permissions=8&scope=bot")
                
            embed.set_author(
                name="Track Bot - {}".format(datetime.datetime.now()), url= "https://media.wired.com/photos/5b6df22751297c21002b4536/2:1/w_2400,h_1200,c_limit/HackerBot.jpg", icon_url= "https://media.wired.com/photos/5b6df22751297c21002b4536/2:1/w_2400,h_1200,c_limit/HackerBot.jpg")
                
            embed.set_thumbnail(
                url = str(after.avatar_url))
            
            
            
            
            #embed = discord.Embed(title=f"{member} just joined the server!", colour = 0xffa500)
                
            #embed.set_image(url=f"attachment://{filename}")
                
            #file=(file, embed=embed)
            await member.dm_channel.send(content=None, embed=embed)
            
            print("sent message to {} about {}".format(data[str(after.id)]["trackedByUser"][i], data[str(after.id)]["username"]))
            
        





@bot.command(name='track', help='Starts tracking a person of your choice. e.g. ktrack @Kopamed#9408')
async def track(ctx, tag):
    
    data = load_json("data.json")
    target_id = tag[3:-1]
    
    if auth
    
    

    
    
    
    
@bot.command(name='ping', help='Returns your ping')
async def ping(ctx):
  embed= discord.Embed(
    title="Pong",
    description="`{0}ms`". format(round(bot.latency * 100, 0)),
    colour=discord.Colour(0x187bcd  ))
  embed.set_footer(
    text="https://discord.com/oauth2/authorize?client_id=749989132763136021&permissions=8&scope=bot")
  embed.set_author(
    name="Track Bot", url= "https://media.wired.com/photos/5b6df22751297c21002b4536/2:1/w_2400,h_1200,c_limit/HackerBot.jpg", icon_url= "https://media.wired.com/photos/5b6df22751297c21002b4536/2:1/w_2400,h_1200,c_limit/HackerBot.jpg")
  embed.set_thumbnail(
    url = str(ctx.author.avatar_url))
  
  await ctx.send(embed=embed)
bot.run(TOKEN)